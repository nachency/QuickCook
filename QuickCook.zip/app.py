from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def index():
	return render_template('index.html')

app.run('0.0.0.0',8080)

@app.route('/recipes')
def recipes():
  return recipes

@app.route('/aboutus')

@app.route('/shoppingcart')

@app.route('/downloadQuickCook')

@app.route('/')